명령어 
1. ./server 포트번호
2. ./client 아이피주소 포트번호

컴파일 할때 명령어 

gcc -o client client.cpp -lstdc++ -ljson-c -lpthread

